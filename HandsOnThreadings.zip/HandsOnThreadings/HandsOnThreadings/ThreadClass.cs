﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HandsOnThreadings
{
    class ThreadClass
    {
        public static void Threads()
        {
            int a = 0;
            for (int t = 0; t < 6; t++)
            {
                Console.WriteLine("Name of Thread: " + ThreadForm.threadA.Name + "Process = " + a++);
                Thread.Sleep(1000);
            }
        }
        public static void Thread1()
        {
            int b = 0;
            for (int t = 0; t < 6; t++)
            {
                Console.WriteLine("Name of Thread: " + ThreadForm.threadA.Name + "Process = " + b++);
                Thread.Sleep(1000);
            }
        }
    }
}
