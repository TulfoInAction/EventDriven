﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03HANDSONEVENTDRIVEN
{
    class StudentInformationClass
    {
        public static int SetStudentNo = 0;
        public static long SetContactNo = 0;
        public static int SetAge;
        public static string SetProgram = " ";
        public static string SetGender = " ";
        public static string SetBirthDay = " ";
        public static string SetFullName = " ";
    }
}
