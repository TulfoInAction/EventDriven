﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _03HANDSONEVENTDRIVEN
{
    public partial class frmRegistration : Form
    {
        private string _FullName;
        private int _Age;
        private long _ContactNo;
        private long _StudentNo;

        public long StudentNumber(string studNum)
        {
            _StudentNo = long.Parse(studNum);
            return _StudentNo;
        }
        public string FullName(string LastName, string FirstName, string MiddleInitial)
        {
            if (Regex.IsMatch(LastName, @"^[a-zA-Z\s]+$") && Regex.IsMatch(FirstName, @"^[a-zA-Z\s]+$") && Regex.IsMatch(MiddleInitial, @"^[a-zA-Z]+$"))
            {
                _FullName = LastName + ", " + FirstName + ", " + MiddleInitial;
            }
            //CHALLENGE #2
            else
            {
                throw new ArgumentException("Please enter a valid name (Only letters from A-Z)");
            }
            return _FullName;
        }
        public int Age(string age)
        {
            if (Regex.IsMatch(age, @"^[0-9]{1,3}$"))
            {
                _Age = Int32.Parse(age);
            }
            //CHALLENGE #2
            else
            {
                throw new ArgumentException("Please write a valid age (Only numbers not exceeding 3 digits)");
            }
            return _Age;
        }
        public frmRegistration()
        {
            InitializeComponent();
        }
        public long ContactNo(string Contact)
        {
            if (Regex.IsMatch(Contact, @"^[0-9]{10,11}$"))

            {
                _ContactNo = long.Parse(Contact);
            }
            //CHALLENGE #2
            else
            {
                throw new ArgumentException("Please enter a valid enter a valid contact number (Only numbers with and must be atleast 10-11 digits)");
            }
            return _ContactNo;
        }
        private void frmRegistration_Load(object sender, EventArgs e)
        {
            string[] ListOfProgram = new string[]
            {
                "BS Information Technology",
                "BS Computer Science",
                "BS Information Systems",
                "BS in Accountancy",
                "BS in Hospitality Management",
                "BS in Tourism management"
            };

            for (int i = 0; i < 6; i++)
            {
                cbPrograms.Items.Add(ListOfProgram[i].ToString());
            }
            string[] ListOfGender = new string[]
            {
                "Male",
                "Female",
            };

            for (int s = 0; s < 2; s++)
            {
                cbGender.Items.Add(ListOfGender[s].ToString());
            }
        }

        private void Register_Click(object sender, EventArgs e)
        {
            //CHALLENGE #1
            try
            {
                StudentInformationClass.SetFullName = FullName(txtLastName.Text, txtFirstName.Text, txtMiddleInitial.Text);
                StudentInformationClass.SetStudentNo = (int)StudentNumber(txtStudentNo.Text);
                StudentInformationClass.SetProgram = cbPrograms.Text;
                StudentInformationClass.SetGender = cbGender.Text;
                StudentInformationClass.SetContactNo = (long)ContactNo(txtContactNo.Text);
                StudentInformationClass.SetAge = Age(txtAge.Text);
                StudentInformationClass.SetBirthDay = datePickerBirtday.Value.ToString("yyyy- MM-dd");

                frmConfirmation frm = new frmConfirmation(); frm.ShowDialog();
            }
            //CHALLENGE #3
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //CHALLENGE #3
            catch (ArgumentNullException ex)
            {
                MessageBox.Show(ex.Message);
            }
            // CHALLENGE #3
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //CHALLENGE #3
            catch (OverflowException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //CHALLENGE #3
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //CHALLENGE #1
            finally
            {
                MessageBox.Show("Execution complete");
            }
        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    
}
